"""
Generic event plugin for the Sigma Event Processor.
This plugin handles events that don't match any other plugin.
"""
import html
import json
import logging
from typing import Dict, Any

from plugins.base import EventSourcePlugin

logger = logging.getLogger()

class GenericEventPlugin(EventSourcePlugin):
    """Plugin for processing generic events."""
    
    def get_plugin_name(self) -> str:
        """Get the name of the plugin."""
        return "generic"
    
    def get_event_type(self) -> str:
        """Get the event type this plugin handles."""
        return "Generic"
    
    def can_process_event(self, event: Dict[str, Any]) -> bool:
        """
        Check if this plugin can process the given event.
        
        Args:
            event: The event to check
            
        Returns:
            bool: True if this plugin can process the event
        """
        # This plugin can process any event that doesn't match other plugins
        return True
    
    def extract_actor(self, event: Dict[str, Any]) -> str:
        """
        Extract the actor from a generic event.
        
        Args:
            event: The event
            
        Returns:
            str: The actor identifier
        """
        # Try to get the actor from the event
        actor = event.get('actor', '')
        
        # If no actor is set, try to extract it from common fields
        if not actor:
            # Try different fields in order of preference
            actor = (
                event.get('userIdentity', {}).get('arn', '') or
                event.get('userIdentity', {}).get('userName', '') or
                event.get('userIdentity', {}).get('type', '') or
                event.get('sourceIPAddress', '') or
                event.get('source', '') or
                'unknown'
            )
        
        return actor
    
    def generate_event_section(self, event: Dict[str, Any]) -> str:
        """
        Generate an HTML section for a generic event.
        
        Args:
            event: The event
            
        Returns:
            str: HTML section for the event
        """
        # Extract and escape event details
        event_type = html.escape(str(event.get('eventType', 'unknown')))
        event_name = html.escape(str(event.get('eventName', 'unknown')))
        event_source = html.escape(str(event.get('eventSource', event.get('source', 'unknown'))))
        actor = html.escape(str(self.extract_actor(event)))
        source_ip = html.escape(str(event.get('sourceIPAddress', 'unknown')))
        timestamp = html.escape(str(event.get('eventTime', 'unknown')))
        region = html.escape(str(event.get('awsRegion', 'unknown')))
        account_id = html.escape(str(event.get('recipientAccountId', 'unknown')))
        
        # Generate HTML section
        section = f"""
        <div class='section'>
            <div class='section-title'>Event Information</div>
            <div class='section-body'>
                <div class='detail-row'>
                    <div class='detail-label'>Time</div>
                    <div class='value'>{timestamp}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Event</div>
                    <div class='value'>{event_name}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Event Source</div>
                    <div class='value'>{event_source}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Actor</div>
                    <div class='value'>{actor}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Source IP</div>
                    <div class='value'>{source_ip}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Region</div>
                    <div class='value'>{region}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Account ID</div>
                    <div class='value'>{account_id}</div>
                </div>
                <div class='detail-row'>
                    <div class='detail-label'>Event Type</div>
                    <div class='value'>{event_type}</div>
                </div>
            </div>
        </div>
        """
        
        return section
    
    def get_event_details(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract relevant details from a generic event.
        
        Args:
            event: The event
            
        Returns:
            Dict[str, Any]: Dictionary containing event details
        """
        details = {
            'eventType': event.get('eventType', 'unknown'),
            'actor': self.extract_actor(event),
            'sourceIPAddress': event.get('sourceIPAddress', 'unknown'),
            'eventTime': event.get('eventTime', 'unknown'),
            'awsRegion': event.get('awsRegion', 'unknown'),
            'recipientAccountId': event.get('recipientAccountId', 'unknown'),
            'userAgent': event.get('userAgent', 'unknown'),
            'requestParameters': event.get('requestParameters', {}),
            'responseElements': event.get('responseElements', {}),
            'errorCode': event.get('errorCode', 'unknown'),
            'errorMessage': event.get('errorMessage', 'unknown')
        }
        
        return details 